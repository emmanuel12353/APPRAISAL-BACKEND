import supervisor from "../Model/supervisor"

export const SupervisorLogin = async()=> {
console.log('i am ready to fly')
}

