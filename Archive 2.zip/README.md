# GitHub Codespaces ♥️ Express

this is a backend code of an appraisal portal. 
it give a supervisor the ability to appraise his/her staff and also see staff that was appraised

it also gives the opputunity to download the apprased staffs

```
npm start
```
# Outsourced-staff-appraisal-backend-codespace-opulent-fiesta-469v9wwgqj627qxg
